function Meavalue=Mea(U,B,D,Dclass_matrxi,bel,t,meafun)
if nargin(meafun)==4
    Meavalue=meafun(U,B,Dclass_matrxi,bel);
elseif nargin(meafun)==5
    Meavalue=meafun(U,B,Dclass_matrxi,bel,t);
elseif nargin(meafun)==6
    Meavalue=meafun(U,B,D,Dclass_matrxi,bel,t);
end
end