function [reduct,Sig]=core_reduct(U,C,D,Dclass_matrxibel,bel,t,meafun)
Q=C;
P=[];
[~,mQ]=size(Q);
Qnum=1:mQ;
[~,mP]=size(P);
Pnum=1:mP;
ss=0;
kk=0;
while ~isempty(Qnum)
    kk=kk+1;
    ss=ss+1;
    Q_P=setdiff(Qnum,Pnum);
    k=length(Q_P);
    if mod(k,2)== 0
        induce=k/2;
    else
        induce=floor(k/2)+1;
    end
    sd_Pl_P_D=zeros(1,induce);
    
    %% Mea_P
    if isempty(P)
        mea_P=0;
    else
        if nargin(meafun)==4
            mea_P=meafun(U,P,Dclass_matrxibel,bel);
        elseif nargin(meafun)==5
            mea_P=meafun(U,P,Dclass_matrxibel,bel,t);
        elseif nargin(meafun)==6
            mea_P=meafun(U,P,D,Dclass_matrxibel,bel,t);
        end
    end
    
    for Plnum=1:induce
        if Plnum==floor(k/2)+1
            plnum=Q_P(2*Plnum-1);
        else
            plnum=Q_P(2*Plnum-1:2*Plnum);
        end
        P1=Q(:, plnum);
       %% Mea_P_P1 
        P1=[P P1];
        if nargin(meafun)==4
            mea_P_P1=meafun(U,P1,Dclass_matrxibel,bel);
        elseif nargin(meafun)==5
            mea_P_P1=meafun(U,P1,Dclass_matrxibel,bel,t);
        elseif nargin(meafun)==6
            mea_P_P1=meafun(U,P1,D,Dclass_matrxibel,bel,t);
        end
        sd_Pl_P_D(Plnum)=abs(mea_P_P1-mea_P);
    end
    
    Sig{kk}=sd_Pl_P_D;
    %     if max(sd_Pl_P_D)<=0
    if ss==1
        reduct=1:mQ;
    else
        reduct=Pnum;
    end
    %         return
    %     end
    [~,I]=max(sd_Pl_P_D);
    if I==floor(k/2)+1
        Inum=Q_P(2*I-1);
    else
        Inum=Q_P(2*I-1:2*I);
    end
    Pnum=[Pnum Inum];
    P=C(:,Pnum);
    Qnum=setdiff(Qnum,Inum);
end
reduct=Pnum;
end

function Meavalue=Mea(U,B,D,Dclass_matrxi,bel,t,meafun)
if nargin(meafun)==4
    Meavalue=meafun(U,B,Dclass_matrxi,bel);
elseif nargin(meafun)==5
    Meavalue=meafun(U,B,Dclass_matrxi,bel,t);
elseif nargin(meafun)==6
    Meavalue=meafun(U,B,D,Dclass_matrxi,bel,t);
end
end