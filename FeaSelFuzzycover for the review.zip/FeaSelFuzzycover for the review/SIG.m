function sig=SIG(U,P1,P,D,Dclass_matrxibel,bel,t,meafun)
P1=[P P1];
if nargin(meafun)==4
    mea_P_P1=meafun(U,P1,Dclass_matrxibel,bel);
elseif nargin(meafun)==5
    mea_P_P1=meafun(U,P1,Dclass_matrxibel,bel,t);
elseif nargin(meafun)==6
    mea_P_P1=meafun(U,P1,D,Dclass_matrxibel,bel,t);
end

if isempty(P)
    mea_P=0;
else
    if nargin(meafun)==4
        mea_P=meafun(U,P,Dclass_matrxibel,bel);
    elseif nargin(meafun)==5
        mea_P=meafun(U,P,Dclass_matrxibel,bel,t);
    elseif nargin(meafun)==6
        mea_P=meafun(U,P,D,Dclass_matrxibel,bel,t);
    end
    
end


sig=mea_P_P1-mea_P;
end