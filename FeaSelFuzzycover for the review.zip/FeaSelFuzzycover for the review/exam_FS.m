clear
clc
data=[0.7 0.9 0.4 0.6 0.7 0.7	0.7	0.9	1
    0.6	0.9	0.3	0.7	0.6	0.8	0.6	0.8	1
    0.6	0.5	0.3	0.5	0.9	0.9	0.8	0.5	0
    0.3	0.5	0.2	0.2	0.2	0.2	0.3	0.5	0
    0.5	0.8	0.4	0.6	0.5	0.4	0.5	0.8	1
    ];
train_data=data(:,1:end-1);
train_label=data(:,end);
[row, attrinu]=size(train_data);
U=[1:row]';
bel=0.75;
t=0.3;

funcHandles = { @CH_O};
algname = {'HO_FS'};
SENUM=[];
Dclass_matrxi=D_EleMatrix(U,train_data,train_label,bel);
for k=1
    [Senum,sig] =core_reduct(U,train_data,train_label,Dclass_matrxi,bel,t,funcHandles{k});
    SENUM=[SENUM;Senum];
    
    NAME=[algname{k} 'Senum'];
    eval([NAME, '=Senum;']);
        NAME=[algname{k} 'sig'];
    eval([NAME, '=sig;']);
end

