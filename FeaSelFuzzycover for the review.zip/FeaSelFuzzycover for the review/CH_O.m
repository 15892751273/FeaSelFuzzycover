function ch_d=CH_O(U,P,Dclass_matrxi,bel,t)
m=length(U);
[~,Bnum]=size(P);
CH_u=zeros(m,m);
unline_t=t.*ones(1,m);

if mod(Bnum,2)== 0
    induce=Bnum/2;
else
    induce=floor(Bnum/2)+1;
end


for k=1:induce
    if k==floor(Bnum/2)+1
        XM{k}=FbelN(U,P(:,2*k-1),bel);
    else
        XM{k}=FbelN(U,P(:,2*k-1:2*k),bel);
    end
end

for j=1:m
    for k=1:induce
        xmatrix_P_k_bel=XM{k};
        CH_u(j,:)=max(CH_u(j,:),xmatrix_P_k_bel(j,:));
    end
end
CH=sum(sum(CH_u));
mCHD_u=zeros(m,m);
CHD_u=zeros(m,m);
for j=1:m
    for k=1:induce
        xmatrix_P_k_bel=XM{k};
        mCHD_u(j,:)=max(CH_u(j,:),xmatrix_P_k_bel(j,:));
    end
    D_ut=max(Dclass_matrxi(j,:),unline_t);
    CHD_u(j,:)=min(mCHD_u(j,:),D_ut);
end
CHD=sum(sum(CHD_u));
ch_d=log(CH/CHD);
